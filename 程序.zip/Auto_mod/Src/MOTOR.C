
#include "MOTOR.H"
int ConnectFlag=0;
int TIMC_Flag=0,TIMC_Flag2=0;
int CTx,CTy,len,showflag,showflag2,sflag=1,CTR2;
int targetX=0,targetY=0,OpMode=0;
int exflag=0,Go_Flag;
int CT=0,CTR=0;
int Speed=101,Target,Step_ON=0;
void Motor_IO_Init()
{

//  GPIO_InitTypeDef  GPIO_InitStructure;
//  	
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC, ENABLE);
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//  
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOC, &GPIO_InitStructure);

//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15|GPIO_Pin_14|GPIO_Pin_12|GPIO_Pin_13;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
// 	
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15|GPIO_Pin_14;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
//  GPIO_Init(GPIOC, &GPIO_InitStructure);
}
void Auto_Step_to(long int X)
{
	Target=X*1800;
	Step_ON=1;
}

void Manual_Step_Scan()
{

		if(Go_Flag==0)
		{
			One_Step(0);	
			showflag=0;
			return;
		}
		if(Go_Flag==1)
		{
			One_Step(1);	
			showflag=0;
			return;
		}
	Motor_Init();
}
void Motor_Init()
{
	MX0_L;
  MX1_L;		    
  MX2_L;
  MX3_L;
	MY0_L;
  MY1_L;
  MY2_L;
  MY3_L;	
	exflag=0;
}
int Mach_Init()
{
	int ttt=0;
	while(1)
	{
		if(SWX==1)
		One_Step(1);
		if(SWX==0||START_SW==0)
		{
			HAL_Delay(10);
			if(SWX==0||START_SW==0)
			{
				CTx=0;CTy=0;
				Motor_Init();
				LED_RUNNING_OFF;
				LED_LAVA_OFF;
				LED_RINSE_OFF;
				LED_DRAIN_OFF;
				BEEP_ON;
				HAL_Delay(100);
				BEEP_OFF;
				HAL_Delay(100);
				BEEP_ON;
				HAL_Delay(100);
				BEEP_OFF;
				return 1;
			}
		}
		if(ttt>100000)//����
		{
		LED_RUNNING_ON;
		LED_LAVA_ON;
		LED_RINSE_ON;
		LED_DRAIN_ON;
		}
		else
		{
			LED_RUNNING_OFF;
			LED_LAVA_OFF;
			LED_RINSE_OFF;
			LED_DRAIN_OFF;
		}
		ttt++;
		if(ttt>=200000)
			ttt=0;
	}
}

void One_Step(int dir)//0-X��ת��1-X��ת��2-Y��ת��3-Y��ת
{
exflag=1;
if(dir==0)
	{
	switch(CTR)
    {
       case 0:
          if(TIMC_Flag)   // A
          {				    
            MX0_L;		    //0xf1  
            MX1_H;
						MX2_H;
            MX3_H;
            CTR = 1;
						CTx++;
						TIMC_Flag=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag)
          {	
            MX0_L;		   //0xf3 
            MX1_L;
           	MX2_H;
            MX3_H;
            CTR = 2;
						CTx++;
			TIMC_Flag=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag)
          {
           
          	MX0_H;
            MX1_L;		  //0xf2 
            MX2_H;
            MX3_H;
           CTx++;
            CTR = 3;
			TIMC_Flag=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_L;		    //0xf6
            MX2_L;
            MX3_H;
            CTR = 4;
						CTx++;
			TIMC_Flag=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_H;		    //0xf4
            MX2_L;
            MX3_H;
            CTR = 5;
						CTx++;
			TIMC_Flag=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_H;		    //0xfc
            MX2_L;
            MX3_L;
            CTR = 6;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_H;		    //0xf8
            MX2_H;
            MX3_L;
            CTR = 7;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag)
          {	
            MX0_L;
            MX1_H;		    //0xf9
            MX2_H;
            MX3_L;
            CTR = 0;
						CTx++;
			TIMC_Flag=0;
          }
       break;
	}
 }
 if(dir==1)
	{
	switch(CTR)
    {
       case 0:
          if(TIMC_Flag)   // A
          {				    
            MX0_L;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MX1_H;
						MX2_H;
            MX3_L;
						CTx--;
            CTR = 1;
			TIMC_Flag=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag)
          {	
            MX0_H;		   //0xf3 
            MX1_H;
           	MX2_H;
            MX3_L;
						CTx--;
            CTR = 2;
			TIMC_Flag=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag)
          {
           
          	MX0_H;
            MX1_H;		  //0xf2 
            MX2_L;
            MX3_L;
           CTx--;
            CTR = 3;
			TIMC_Flag=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_H;		    //0xf6
            MX2_L;
            MX3_H;
						CTx--;
            CTR = 4;
			TIMC_Flag=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_L;		    //0xf4
            MX2_L;
            MX3_H;
						CTx--;
            CTR = 5;
			TIMC_Flag=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag)
          {	
            MX0_H;
            MX1_L;		    //0xfc
            MX2_H;
            MX3_H;
						CTx--;
            CTR = 6;
			TIMC_Flag=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag)
          {	
            MX0_L;
            MX1_L;		    //0xf8
            MX2_H;
            MX3_H;
						CTx--;
            CTR = 7;
			TIMC_Flag=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag)
          {	
            MX0_L;
            MX1_H;		    //0xf9
            MX2_H;
            MX3_H;
						CTx--;
            CTR = 0;
			TIMC_Flag=0;
          }
       break;
	}
 }
 	if(dir==2)
	{
		switch(CTR2)
    {
       case 0:
          if(TIMC_Flag2)   // A
          {				    
            MY0_L;		    //0xf1             0111 0011 1011 1001 1101 1100 1110 0110
            MY1_H;
						MY2_H;
            MY3_L;
						CTy++;
            CTR2 = 1;
			TIMC_Flag2=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag2)
          {	
            MY0_H;		   //0xf3 
            MY1_H;
           	MY2_H;
            MY3_L;
						CTy++;
            CTR2 = 2;
			TIMC_Flag2=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag2)
          {
           
          	MY0_H;
            MY1_H;		  //0xf2 
            MY2_L;
            MY3_L;
           CTy++;
            CTR2 = 3;
			TIMC_Flag2=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_H;		    //0xf6
            MY2_L;
            MY3_H;
						CTy++;
            CTR2 = 4;
			TIMC_Flag2=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_L;		    //0xf4
            MY2_L;
            MY3_H;
						CTy++;
            CTR2 = 5;
			TIMC_Flag2=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_L;		    //0xfc
            MY2_H;
            MY3_H;
						CTy++;
            CTR2 = 6;
			TIMC_Flag2=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag2)
          {	
            MY0_L;
            MY1_L;		    //0xf8
            MY2_H;
            MY3_H;
						CTy++;
            CTR2 = 7;
			TIMC_Flag2=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag2)
          {	
            MY0_L;
            MY1_H;		    //0xf9
            MY2_H;
            MY3_H;
						CTy++;
            CTR2 = 0;
			TIMC_Flag2=0;
          }
       break;
			}
}
	if(dir==3)
	{
		switch(CTR2)
    {
       case 0:
          if(TIMC_Flag2)   // A
          {				    
            MY0_L;		    //0xf1  
            MY1_H;
						MY2_H;
            MY3_H;
						CTy--;
            CTR2 = 1;
			TIMC_Flag2=0;
          }
       break;

       case 1:		 // AB
         if(TIMC_Flag2)
          {	
            MY0_L;		   //0xf3 
            MY1_L;
           	MY2_H;
            MY3_H;
						CTy--;
            CTR2 = 2;
			TIMC_Flag2=0;
          }
       break;

       case 2:	   //B
         if(TIMC_Flag2)
          {
           
          	MY0_H;
            MY1_L;		  //0xf2 
            MY2_H;
            MY3_H;
						CTy--;
            CTR2 = 3;
			TIMC_Flag2=0;
          }
       break;


       case 3:		//BC
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_L;		    //0xf6
            MY2_L;
            MY3_H;
						CTy--;
            CTR2 = 4;
			TIMC_Flag2=0;
          }
       break;
     case 4:		 //C
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_H;		    //0xf4
            MY2_L;
            MY3_H;
						CTy--;
            CTR2 = 5;
			TIMC_Flag2=0;
           }
       break;
	case 5:			  //CD
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_H;		    //0xfc
            MY2_L;
            MY3_L;
						CTy--;
            CTR2 = 6;
			TIMC_Flag2=0;
          }
       break;
	case 6:			  //D
         if(TIMC_Flag2)
          {	
            MY0_H;
            MY1_H;		    //0xf8
            MY2_H;
            MY3_L;
						CTy--;
            CTR2 = 7;
			TIMC_Flag2=0;
          }
       break;
	case 7:			//DA
         if(TIMC_Flag2)
          {	
            MY0_L;
            MY1_H;		    //0xf9
            MY2_H;
            MY3_L;
						CTy--;
            CTR2 = 0;
			TIMC_Flag2=0;
          }
       break;
	
	}
}
}
